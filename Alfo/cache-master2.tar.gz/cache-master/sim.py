#!/usr/bin/python
#! -*- coding: utf-8 -*-
import os
import time
import sys

import CLOCK, LRU, LFU, OPT, ARC, LIRS, RANDOM, kRANDOM_LRU, SkLRU

l = { "CLOCK": CLOCK,
      "LRU": LRU,
      "LFU": LFU,
      "OPT": OPT,
      "LIRS": LIRS,
      "ARC": ARC,
      "RANDOM": RANDOM,
#      "kRANDOM_LRU": kRANDOM_LRU, #  handled differently
}

ls="RANDOM"
#ss="5 30 50 70 100 200 300 400 500 600 700 800 900 1000 1100 1200 1300 1400 1500"
ss=[5, 30, 50, 70, 100, 200]

def rename_files():
    p = 1
    path = os.getcwd()+'/traces/'
    #name = 'trace_'+str(p)
    #os.rename(path+'Bremote_house1_Dec-r1_2011_1min_fullrate_wo_planetlab_0Mbps_wireless_iperf_hub_sniff_linux_tcp_1_r1.wshark',name)
    for x in os.listdir(path):
        name = 'trace_'+str(p)
        os.rename(path+x,path+name)
        p+=1


def fillspace(s):
    return s + " " * (20 - len(s))

def doitall():
    path = os.getcwd()+'/traces/'
    x = 'trace_1'
    #for x in os.listdir(path):
    print x

    algn = ls
    k = None
    if algn.find("RANDOM_LRU") >= 0:
        algm = kRANDOM_LRU
        k = int(algn.replace("RANDOM_LRU_", ""))
    elif algn[0] == "S" and algn.find("LRU") > 0:
        algm = SkLRU
        k = int(algn[1:].replace("LRU", ""))
    elif algn not in l:
        print "Algorithm: %s does not exist" % algn
        exit()
    else:
        algm =  l[algn]

    for x in os.listdir(path):
        f = open(path+x, "r")
        c = int(ss[3])
        lines = f.readlines()
        f.close()

        alg = algm.alg(c, k=k)
        alg.setup(lines)

        time1 = time.time()

        lc = 0
        for line in lines:
            lc += 1
            b = line.replace("\n", "").lstrip()
            key = b.split(" ")[0]
            print 'key del trace: '+ str(key)
            ret = alg.get(key)
            if not ret:
                alg.put(key, 1)

            time2 = time.time()
            diff = time2-time1
            tp = lc / (0.0 + diff)
            hr = alg.hitcount / (0.0 + alg.count)
            print "hitcount: " +str(alg.hitcount)
            print "%s %d %.4f %.2f" % (str(alg), c, 100.0*hr, tp)
            #sys.stderr.write("%s with %d\tHit ratio: %.4f\tThroughput: %.2f (reqs/s)\n" % (fillspace(str(alg)), c, hr, tp))


if __name__ == "__main__":
    #rename_files()
    doitall()

    